﻿namespace Quadrant
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtXValue = new System.Windows.Forms.TextBox();
            this.txtYValue = new System.Windows.Forms.TextBox();
            this.lblIntro1 = new System.Windows.Forms.Label();
            this.lblIntro2 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.lblOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtXValue
            // 
            this.txtXValue.Location = new System.Drawing.Point(50, 141);
            this.txtXValue.Name = "txtXValue";
            this.txtXValue.Size = new System.Drawing.Size(100, 20);
            this.txtXValue.TabIndex = 0;
            // 
            // txtYValue
            // 
            this.txtYValue.Location = new System.Drawing.Point(214, 141);
            this.txtYValue.Name = "txtYValue";
            this.txtYValue.Size = new System.Drawing.Size(100, 20);
            this.txtYValue.TabIndex = 1;
            // 
            // lblIntro1
            // 
            this.lblIntro1.AutoSize = true;
            this.lblIntro1.Location = new System.Drawing.Point(50, 104);
            this.lblIntro1.Name = "lblIntro1";
            this.lblIntro1.Size = new System.Drawing.Size(72, 13);
            this.lblIntro1.TabIndex = 2;
            this.lblIntro1.Text = "Enter X Value";
            // 
            // lblIntro2
            // 
            this.lblIntro2.AutoSize = true;
            this.lblIntro2.Location = new System.Drawing.Point(227, 104);
            this.lblIntro2.Name = "lblIntro2";
            this.lblIntro2.Size = new System.Drawing.Size(72, 13);
            this.lblIntro2.TabIndex = 3;
            this.lblIntro2.Text = "Enter Y Value";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(139, 209);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(94, 34);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "Calculate";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Location = new System.Drawing.Point(127, 299);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(39, 13);
            this.lblOutput.TabIndex = 5;
            this.lblOutput.Text = "Output";
            this.lblOutput.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkOrange;
            this.ClientSize = new System.Drawing.Size(366, 365);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.lblIntro2);
            this.Controls.Add(this.lblIntro1);
            this.Controls.Add(this.txtYValue);
            this.Controls.Add(this.txtXValue);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quadrant Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtXValue;
        private System.Windows.Forms.TextBox txtYValue;
        private System.Windows.Forms.Label lblIntro1;
        private System.Windows.Forms.Label lblIntro2;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label lblOutput;
    }
}

