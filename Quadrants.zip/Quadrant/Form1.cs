﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Lakshay Punj
//April 04, 2019
//Program to output which quadrant point is in

namespace Quadrant
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            //Declaring Variables

            int XVal = int.Parse(txtXValue.Text);
            int YVal = int.Parse(txtYValue.Text);

            //If/Else statements and rounding

            //Code for Quadrant 1 output
            if (XVal >=0 && YVal >= 0)
            {
                lblOutput.Text = "Point is located in Quadrant 1";
            }
            //Code for Quadrant 2 output
            else if (XVal <=0 && YVal >=0)
            {
                lblOutput.Text = "Point is located in Quadrant 2";
            }
            //Code for Quadrant 3 output
            else if (XVal <=0 && YVal <=0)
            {
                lblOutput.Text = "Point is located in Quadrant 3";
            }
            //Code for Quadrant 4 output
            else if (XVal >= 0 && YVal <=0)
            {
                lblOutput.Text = "Point is located in Quadrant 4";
            }
            //Code for Else, enter valid input
            else
            {
                lblOutput.Text = "Enter valid inputs :)";
            }

            //Makes output visible when output appears
            lblOutput.Visible = true;


        }
    }
}
